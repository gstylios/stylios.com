---
layout: page
title: "Home"
permalink: /
---

This is my private website. As I am in the 4th quartile of life, it's about me. If you're interested, navigate by selecting the different pages; if not, feel free to quit and do something else.

## Pages

- [About Me](/AboutMe)
- [Life Highlights](/LifeHighlights)
- [My Journey](/MyJourney)
- [My Academic Work](/MyAcademicWork)
- [My Beliefs](/MyBeliefs)
- [My Hobbies](/MyHobbies)
- [Photo Gallery](PhotoGallery)
