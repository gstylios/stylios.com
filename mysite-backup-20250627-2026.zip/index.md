---
layout: page
title: "" 
permalink: /
---


This is my private website, as I am running in the 4th quartile of life, its about me, so if interested navigate by selecting the diffrent pages, if not interested quit and do something else.
